#This script is used to select individual phenotypes
#after the users have examined and chosen phenotypes

select.pheno <- function(data.obj, phenotypes){
	
	pheno <- data.obj$pheno
	pheno.col <- get.col.num(pheno, phenotypes)

	if(length(pheno.col) > 0){
		new.pheno <- pheno[,pheno.col]
		data.obj$pheno <- new.pheno
		}

	return(data.obj)
	
}